/**
 * Gameday Board proxy: a Cloudflare Worker (works on the free plan).
 *
 * What it does: the website asks this Worker for sports data, the Worker fetches
 * it from ESPN, MLB or Sleeper on the server side, and sends it back with the header that
 * lets a browser read it (CORS).
 *
 * What it refuses: everything except the few scoreboard, standings and stat
 * addresses listed below. It is not a general-purpose proxy.
 *
 * It can also send notifications to phones and computers when the site is closed. To turn that on, in the
 * Cloudflare dashboard: (1) create a KV namespace (Storage & Databases > KV), (2) in this Worker's Settings > Bindings
 * add it as a "KV namespace" binding with the variable name PUSH, (3) in Settings > Triggers add a Cron Trigger "* * * * *"
 * (every minute). Without those, the proxy works exactly as before.
 *
 * How the site calls it:
 *   https://YOUR-WORKER.workers.dev/?url=https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard
 */

// OPTIONAL: only let your own website use this proxy from a browser.
// Leave the list empty to allow any website. Add your site's address once it is published.
const ALLOWED_ORIGINS = [
  // 'https://your-site.pages.dev',
];

// The only addresses this proxy will fetch. `ttl` is how many seconds an answer is reused.
const LEAGUES = '(football/nfl|baseball/mlb|basketball/nba)';
const ALLOWED = [
  { host: 'site.api.espn.com',     path: new RegExp('^/apis/site/v2/sports/' + LEAGUES + '/scoreboard$'), ttl: 4 },
  { host: 'site.web.api.espn.com', path: new RegExp('^/apis/site/v2/sports/' + LEAGUES + '/scoreboard$'), ttl: 4 },
  { host: 'site.api.espn.com',     path: new RegExp('^/apis/v2/sports/' + LEAGUES + '/standings$'),       ttl: 300 },
  { host: 'site.web.api.espn.com', path: new RegExp('^/apis/v2/sports/' + LEAGUES + '/standings$'),       ttl: 300 },
  { host: 'statsapi.mlb.com',      path: /^\/api\/v1\/standings$/,                                        ttl: 300 },
  { host: 'statsapi.mlb.com',      path: /^\/api\/v1\/schedule$/,                                         ttl: 60 },
  { host: 'site.api.espn.com',     path: new RegExp('^/apis/site/v3/sports/' + LEAGUES + '/leaders$'),    ttl: 600 },
  { host: 'statsapi.mlb.com',      path: /^\/api\/v1\/stats\/leaders$/,                                    ttl: 600 },
  { host: 'statsapi.mlb.com',      path: /^\/api\/v1\/schedule\/postseason\/series$/,                          ttl: 30 },
  // one MLB game's play list (pitch by pitch), read to catch ABS challenges between scoreboard refreshes
  { host: 'sports.core.api.espn.com', path: /^\/v2\/sports\/baseball\/leagues\/mlb\/events\/\d{1,12}\/competitions\/\d{1,12}\/plays$/, ttl: 5 },
  // one game's details: box score and win probability
  { host: 'site.api.espn.com',     path: new RegExp('^/apis/site/v2/sports/' + LEAGUES + '/summary$'),     ttl: 8 },
  { host: 'site.web.api.espn.com', path: new RegExp('^/apis/site/v2/sports/' + LEAGUES + '/summary$'),     ttl: 8 },
  // NFL player stats for one week (the page adds the weeks up for its live stat leaders)
  { host: 'api.sleeper.app',       path: /^\/stats\/nfl\/20\d\d\/(1?\d)$/,                                 ttl: 30 },
  { host: 'api.sleeper.com',       path: /^\/stats\/nfl\/20\d\d\/(1?\d)$/,                                 ttl: 30 },
];

// The only query settings that are passed along. Anything else is dropped.
const ALLOWED_PARAMS = ['dates', 'limit', 'week', 'seasontype', 'season', 'level', 'leagueId', 'standingsTypes', 'sportId', 'startDate', 'endDate', 'leaderCategories', 'statGroup', 'leaderGameTypes', 'season_type', 'position[]', 'order_by', 'event', 'page'];
const SAFE_VALUE = /^[A-Za-z0-9,_-]{1,160}$/;

const memory = new Map(); // address -> { at, body }, kept while this Worker instance stays warm

function corsHeaders(origin) {
  const headers = {
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Accept, Content-Type, Authorization',
    'Access-Control-Expose-Headers': 'X-Proxy, X-Proxy-Error, X-Proxy-Cache, X-Upstream-Status',
    'Access-Control-Max-Age': '86400',
    'X-Proxy': 'gameday-board',
  };
  if (!ALLOWED_ORIGINS.length) headers['Access-Control-Allow-Origin'] = '*';
  else {
    headers['Vary'] = 'Origin';
    if (ALLOWED_ORIGINS.includes(origin)) headers['Access-Control-Allow-Origin'] = origin;
  }
  return headers;
}

function json(status, data, headers, extra) {
  return new Response(JSON.stringify(data), {
    status,
    headers: Object.assign({ 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }, headers, extra || {}),
  });
}
const refuse = (status, message, headers) => json(status, { error: message }, headers, { 'X-Proxy-Error': '1' });


/* =====================================================================
   NOTIFICATIONS THAT ARRIVE WHEN THE SITE IS CLOSED (web push)
   Every minute (a Cron Trigger) the Worker reads the NFL, MLB and NBA scoreboards, compares them with the last
   look, and sends a notification to each phone or computer that asked for one. Needs a KV namespace bound as PUSH.
   Sent for: a score (named only when ESPN's last play confirms it), a lead change (basketball: 4th quarter and later),
   the start of a game and the final score. "My teams" subscribers only get their starred teams.
   ===================================================================== */
const PUSH_LEAGUES = { nfl: 'football/nfl', mlb: 'baseball/mlb', nba: 'basketball/nba' };
const PUSH_NAMES = { nfl: 'NFL', mlb: 'MLB', nba: 'NBA' };
// Only the browsers' own push services. Anything else is refused, so nobody can use this Worker to send requests elsewhere.
const PUSH_HOSTS = /^(fcm\.googleapis\.com|[a-z0-9.-]*\.push\.services\.mozilla\.com|updates\.push\.services\.mozilla\.com|web\.push\.apple\.com|[a-z0-9.-]*\.notify\.windows\.com)$/;
const MAX_SUBS = 300;

const b64u = {
  enc(buf) { let s = ''; new Uint8Array(buf).forEach(b => { s += String.fromCharCode(b); }); return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); },
  dec(str) { const s = atob(String(str).replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((String(str).length + 3) % 4)); return Uint8Array.from(s, c => c.charCodeAt(0)); },
};
const utf8 = s => new TextEncoder().encode(s);
function concat(...parts) { const n = parts.reduce((a, p) => a + p.length, 0), out = new Uint8Array(n); let o = 0; parts.forEach(p => { out.set(p, o); o += p.length; }); return out; }
async function hmac(key, data) { const k = await crypto.subtle.importKey('raw', key, { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']); return new Uint8Array(await crypto.subtle.sign('HMAC', k, data)); }

// The Worker's own signing key (VAPID), made once and kept in KV.
async function vapidKeys(env) {
  const saved = await env.PUSH.get('vapid', 'json');
  if (saved && saved.priv && saved.pub) return saved;
  const pair = await crypto.subtle.generateKey({ name: 'ECDSA', namedCurve: 'P-256' }, true, ['sign', 'verify']);
  const keys = { priv: await crypto.subtle.exportKey('jwk', pair.privateKey), pub: b64u.enc(await crypto.subtle.exportKey('raw', pair.publicKey)) };
  await env.PUSH.put('vapid', JSON.stringify(keys));
  return keys;
}
async function vapidHeader(endpoint, keys, subject) {
  const aud = new URL(endpoint).origin;
  const head = b64u.enc(utf8(JSON.stringify({ typ: 'JWT', alg: 'ES256' })));
  const claims = b64u.enc(utf8(JSON.stringify({ aud, exp: Math.floor(Date.now() / 1000) + 12 * 3600, sub: subject })));
  const key = await crypto.subtle.importKey('jwk', keys.priv, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['sign']);
  const sig = await crypto.subtle.sign({ name: 'ECDSA', hash: 'SHA-256' }, key, utf8(head + '.' + claims));
  return 'vapid t=' + head + '.' + claims + '.' + b64u.enc(sig) + ', k=' + keys.pub;
}
// The message is encrypted for that one browser (RFC 8291, "aes128gcm"), so the push service cannot read it.
async function encryptPush(sub, text) {
  const uaPublic = b64u.dec(sub.keys.p256dh), auth = b64u.dec(sub.keys.auth);
  const local = await crypto.subtle.generateKey({ name: 'ECDH', namedCurve: 'P-256' }, true, ['deriveBits']);
  const asPublic = new Uint8Array(await crypto.subtle.exportKey('raw', local.publicKey));
  const uaKey = await crypto.subtle.importKey('raw', uaPublic, { name: 'ECDH', namedCurve: 'P-256' }, false, []);
  const shared = new Uint8Array(await crypto.subtle.deriveBits({ name: 'ECDH', public: uaKey }, local.privateKey, 256));
  const prkKey = await hmac(auth, shared);
  const ikm = await hmac(prkKey, concat(utf8('WebPush: info'), new Uint8Array([0]), uaPublic, asPublic, new Uint8Array([1])));
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const prk = await hmac(salt, ikm);
  const cek = (await hmac(prk, concat(utf8('Content-Encoding: aes128gcm'), new Uint8Array([0, 1])))).slice(0, 16);
  const nonce = (await hmac(prk, concat(utf8('Content-Encoding: nonce'), new Uint8Array([0, 1])))).slice(0, 12);
  const key = await crypto.subtle.importKey('raw', cek, 'AES-GCM', false, ['encrypt']);
  const sealed = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv: nonce }, key, concat(utf8(text), new Uint8Array([2]))));
  const head = new Uint8Array(21); head.set(salt, 0); new DataView(head.buffer).setUint32(16, 4096); head[20] = asPublic.length;
  return concat(head, asPublic, sealed);
}
// Returns the push service's status. 404 / 410 mean that browser has gone away for good.
async function sendPush(env, sub, message, subject) {
  const keys = await vapidKeys(env);
  const body = await encryptPush(sub, JSON.stringify(message));
  const res = await fetch(sub.endpoint, { method: 'POST', redirect: 'manual', body,
    headers: { 'Content-Encoding': 'aes128gcm', 'Content-Type': 'application/octet-stream', TTL: '900', Urgency: 'high', Authorization: await vapidHeader(sub.endpoint, keys, subject) } });
  return res.status;
}
function subId(endpoint) { let h = 0; for (let i = 0; i < endpoint.length; i++) h = (h * 31 + endpoint.charCodeAt(i)) >>> 0; return h.toString(36) + endpoint.length.toString(36); }
function goodSub(s) {
  try {
    const u = new URL(s.endpoint);
    return u.protocol === 'https:' && !u.port && PUSH_HOSTS.test(u.hostname) && s.endpoint.length < 1200 &&
      /^[A-Za-z0-9_-]{80,100}$/.test(s.keys.p256dh) && /^[A-Za-z0-9_-]{16,32}$/.test(s.keys.auth);
  } catch (e) { return false; }
}

// ----- the website's requests: /push/key, /push/subscribe, /push/unsubscribe, /push/test
async function pushRoute(request, env, here, cors) {
  if (!env || !env.PUSH) return refuse(501, 'Notifications are not set up on this Worker yet: add a KV namespace binding named PUSH and a Cron Trigger that runs every minute.', cors);
  const path = here.pathname;
  if (path === '/push/key' && request.method === 'GET') return json(200, { key: (await vapidKeys(env)).pub }, cors);
  if (request.method !== 'POST') return refuse(405, 'Use POST.', cors);
  let input;
  try { input = JSON.parse((await request.text()).slice(0, 8000)); } catch (e) { return refuse(400, 'Send JSON.', cors); }
  const sub = input && input.sub;
  if (!sub || !sub.keys || !goodSub(sub)) return refuse(400, 'That is not a push subscription from a browser\'s push service.', cors);
  const subs = (await env.PUSH.get('subs', 'json')) || {}, id = subId(sub.endpoint);
  if (path === '/push/subscribe') {
    if (!subs[id] && Object.keys(subs).length >= MAX_SUBS) return refuse(507, 'This Worker already has the most subscriptions it keeps (' + MAX_SUBS + ').', cors);
    const favs = (Array.isArray(input.favs) ? input.favs : []).filter(f => /^(nfl|mlb|nba):[A-Z]{2,4}$/.test(f)).slice(0, 40);
    subs[id] = { endpoint: sub.endpoint, keys: { p256dh: sub.keys.p256dh, auth: sub.keys.auth }, mode: input.mode === 'all' ? 'all' : 'mine', favs, at: Date.now(), via: here.origin };
    await env.PUSH.put('subs', JSON.stringify(subs));
    return json(200, { ok: true, mode: subs[id].mode, favs: favs.length }, cors);
  }
  if (path === '/push/unsubscribe') {
    if (subs[id]) { delete subs[id]; await env.PUSH.put('subs', JSON.stringify(subs)); }
    return json(200, { ok: true }, cors);
  }
  if (path === '/push/test') {
    if (!subs[id]) return refuse(404, 'This browser is not subscribed on the Worker.', cors);
    let status;
    try { status = await sendPush(env, subs[id], { title: 'Gameday Board', body: 'Notifications are working. They will arrive even when the site is closed.', tag: 'gb-test' }, here.origin); }
    catch (e) { return refuse(502, 'The Worker could not reach the push service: ' + (e && e.message ? e.message : 'unknown error') + '.', cors); }
    if (status === 404 || status === 410) { delete subs[id]; await env.PUSH.put('subs', JSON.stringify(subs)); }
    return json(status < 300 ? 200 : 502, { ok: status < 300, pushStatus: status }, cors);
  }
  return refuse(404, 'Unknown push address.', cors);
}

// ----- the watcher: what changed since the last look
function slimBoard(raw) {
  return ((raw && raw.events) || []).map(ev => {
    const c = (ev.competitions || [])[0] || {}, st = (c.status || ev.status || {}), t = st.type || {};
    const side = ha => { const x = (c.competitors || []).find(k => k.homeAway === ha) || {}, tm = x.team || {}; return { id: String(tm.id || ''), abbr: String(tm.abbreviation || '').toUpperCase(), name: tm.shortDisplayName || tm.displayName || tm.abbreviation || 'Team', score: x.score == null ? null : Number(x.score) }; };
    const lp = c.situation && c.situation.lastPlay;
    return { id: String(ev.id), state: t.state || '', final: t.completed === true, detail: t.shortDetail || t.detail || '', period: typeof st.period === 'number' ? st.period : 0,
      away: side('away'), home: side('home'), play: lp ? { type: String((lp.type && lp.type.text) || ''), text: String(lp.text || ''), value: typeof lp.scoreValue === 'number' ? lp.scoreValue : null, team: lp.team && lp.team.id != null ? String(lp.team.id) : '' } : null };
  });
}
const leaderOf = g => g.away.score == null || g.home.score == null ? 0 : Math.sign(g.away.score - g.home.score);
// A score is named only when ESPN's last play says so and its points match the change. Otherwise it is "Score update".
function scoreName(lg, g, team, delta) {
  const p = g.play;
  if (!p || p.team !== team.id || (p.value != null && p.value !== delta)) return 'Score update';
  const s = (p.type + ' ' + p.text).toLowerCase();
  if (lg === 'nfl') {
    if (/touchdown/.test(s) && delta >= 6) return 'Touchdown';
    if (/field goal/.test(s) && /good/.test(s) && delta === 3) return 'Field goal';
    if (/safety/.test(s) && delta === 2) return 'Safety';
  }
  if (lg === 'mlb' && /homer|home run/.test(s)) return /grand slam/.test(s) && delta === 4 ? 'Grand slam' : 'Home run';
  return 'Score update';
}
function changes(lg, before, now) {
  const out = [];
  now.forEach(g => {
    const p = before[g.id];
    if (!p) return;
    const pair = g.away.abbr + ' ' + (g.away.score == null ? '' : g.away.score) + ', ' + g.home.abbr + ' ' + (g.home.score == null ? '' : g.home.score);
    const base = { lg, id: g.id, teams: [lg + ':' + g.away.abbr, lg + ':' + g.home.abbr] };
    if (p.s === 'pre' && g.state === 'in') out.push(Object.assign({ title: g.away.name + ' at ' + g.home.name + ' has started', body: PUSH_NAMES[lg], tag: g.id + ':start' }, base));
    if (p.s === 'in' && g.state === 'post') {
      const w = leaderOf(g) > 0 ? g.away : leaderOf(g) < 0 ? g.home : null;
      out.push(Object.assign({ title: 'Final: ' + pair, body: (w ? w.name + ' win' : 'Tied') + ' · ' + PUSH_NAMES[lg], tag: g.id + ':final' }, base));
    }
    if (p.s !== 'in' || g.state !== 'in') return;
    const lead = leaderOf(g), tookLead = lead !== 0 && lead !== p.l;
    if (lg === 'nba') {
      if (g.period >= 4 && p.l !== undefined && tookLead) { const t = lead > 0 ? g.away : g.home; out.push(Object.assign({ title: (p.l === 0 ? 'Take the lead: ' : 'Lead change: ') + t.name, body: pair + ' · ' + g.detail, tag: g.id + ':lead:' + pair }, base)); }
      return;
    }
    ['away', 'home'].forEach(side => {
      const was = side === 'away' ? p.a : p.h, n = g[side].score;
      if (was == null || n == null || n <= was) return;
      const name = scoreName(lg, g, g[side], n - was);
      out.push(Object.assign({ title: name + ': ' + g[side].name + (tookLead && (lead > 0) === (side === 'away') ? ' · ' + (p.l === 0 ? 'take the lead' : 'lead change') : ''),
        body: pair + ' · ' + g.detail + (name !== 'Score update' && g.play ? '\n' + g.play.text.slice(0, 140) : ''), tag: g.id + ':' + pair }, base));
    });
  });
  return out;
}
// What is kept between looks. Basketball keeps only who leads (its score changes too often to store every minute).
function remember(lg, games) {
  const o = {};
  games.forEach(g => { o[g.id] = lg === 'nba' ? { s: g.state, l: leaderOf(g) } : { s: g.state, a: g.away.score, h: g.home.score, l: leaderOf(g) }; });
  return o;
}
async function watchGames(env) {
  if (!env || !env.PUSH) return { skipped: 'no PUSH binding' };
  const subs = (await env.PUSH.get('subs', 'json')) || {}, ids = Object.keys(subs);
  const beat = await env.PUSH.get('beat', 'json');
  if (!beat || Date.now() - beat.at > 20 * 60000) await env.PUSH.put('beat', JSON.stringify({ at: Date.now() }));
  if (!ids.length) return { skipped: 'nobody subscribed' };
  const last = (await env.PUSH.get('last', 'json')) || {}, next = {}, events = [];
  for (const lg of Object.keys(PUSH_LEAGUES)) {
    try {
      const r = await fetch('https://site.api.espn.com/apis/site/v2/sports/' + PUSH_LEAGUES[lg] + '/scoreboard', { headers: { Accept: 'application/json', 'User-Agent': 'Mozilla/5.0 (compatible; GamedayBoardProxy/1.0)' } });
      if (r.status !== 200) { next[lg] = last[lg]; continue; }
      const games = slimBoard(await r.json());
      if (last[lg]) changes(lg, last[lg], games).forEach(e => events.push(e));
      next[lg] = remember(lg, games);
    } catch (e) { next[lg] = last[lg]; }     // a league that did not load keeps its last look, so nothing is announced twice or missed as "new"
  }
  if (JSON.stringify(next) !== JSON.stringify(last)) await env.PUSH.put('last', JSON.stringify(next));   // KV free plan: 1,000 writes a day, so only on a change
  let sent = 0, gone = false;
  const jobs = [];
  for (const id of ids) {
    const s = subs[id];
    const rank = e => /^Final/.test(e.title) ? 0 : / has started$/.test(e.title) ? 3 : /^(Lead change|Take the lead)/.test(e.title) ? 2 : 1;
    const mine = events.filter(e => s.mode === 'all' || e.teams.some(t => s.favs.includes(t)))
      .sort((x, y) => rank(x) - rank(y)).slice(0, 3);   // at most three per minute each; kickoffs go first if something must be left out
    for (const e of mine) {
      if (jobs.length >= 40) break;                        // free plan: 50 outside requests per run, three already used
      jobs.push(sendPush(env, s, { title: e.title, body: e.body, tag: 'gb-' + e.tag, data: { lg: e.lg, id: e.id } }, s.via || 'https://workers.dev').then(st => { sent++; if (st === 404 || st === 410) { delete subs[id]; gone = true; } }, () => {}));
    }
  }
  await Promise.all(jobs);
  if (gone) await env.PUSH.put('subs', JSON.stringify(subs));
  return { events: events.length, sent };
}

/* =====================================================================
   ADMIN: announcements. One device owns the admin panel: the first one to open it claims it and gets a secret key
   (only a fingerprint of the key is kept here). Announcements are public at /ann; adding or removing one needs the key.
   To hand the panel to a new device: delete the "admin" entry in the PUSH KV namespace, then claim again.
   ===================================================================== */
async function sha256(text) { return b64u.enc(await crypto.subtle.digest('SHA-256', utf8(text))); }
async function isAdmin(request, env) {
  const m = /^Bearer ([A-Za-z0-9_-]{40,64})$/.exec(request.headers.get('Authorization') || '');
  if (!m) return false;
  const saved = await env.PUSH.get('admin', 'json');
  return !!(saved && saved.hash && saved.hash === await sha256(m[1]));
}
function liveAnns(list) { const now = Date.now(); return (Array.isArray(list) ? list : []).filter(a => !a.until || a.until > now); }
async function adminRoute(request, env, here, cors) {
  const path = here.pathname;
  if (path === '/ann' && request.method === 'GET') {
    if (!env || !env.PUSH) return json(200, { anns: [] }, cors);
    const hold = memory.get('ann:list');
    const raw = hold && Date.now() - hold.at < 10000 ? hold.body : await env.PUSH.get('ann', 'json');
    if (!hold || hold.body !== raw) memory.set('ann:list', { at: hold && hold.body === raw ? hold.at : Date.now(), body: raw });
    const anns = liveAnns(raw).map(a => ({ id: a.id, text: a.text, level: a.level, link: a.link || '', at: a.at, until: a.until || 0 }));
    return json(200, { anns }, cors, { 'Cache-Control': 'public, max-age=30' });
  }
  if (!env || !env.PUSH) return refuse(501, 'The admin panel needs the KV namespace binding named PUSH on this Worker (the same one notifications use).', cors);
  if (path === '/admin/claim' && request.method === 'POST') {
    if (await env.PUSH.get('admin', 'json')) return refuse(409, 'The admin panel already belongs to another device.', cors);
    const key = b64u.enc(crypto.getRandomValues(new Uint8Array(32)));
    await env.PUSH.put('admin', JSON.stringify({ hash: await sha256(key), at: Date.now() }));
    return json(200, { key }, cors);
  }
  if (path === '/admin/status' && request.method === 'GET') {
    const saved = await env.PUSH.get('admin', 'json');
    const you = await isAdmin(request, env);
    if (!you) return json(200, { claimed: !!saved, you: false }, cors);
    const subs = (await env.PUSH.get('subs', 'json')) || {}, beat = await env.PUSH.get('beat', 'json');
    return json(200, { claimed: true, you: true, devices: Object.keys(subs).length, mine: Object.values(subs).filter(x => x.mode === 'mine').length, lastCheck: beat ? beat.at : 0, now: Date.now() }, cors);
  }
  if (!(await isAdmin(request, env))) return refuse(401, 'Only the admin device can do that.', cors);
  let input = {};
  if (request.method === 'POST') { try { input = JSON.parse((await request.text()).slice(0, 4000)); } catch (e) { return refuse(400, 'Send JSON.', cors); } }
  const list = liveAnns(await env.PUSH.get('ann', 'json'));
  if (path === '/admin/announce' && request.method === 'POST') {
    const text = String(input.text || '').replace(/\s+/g, ' ').trim().slice(0, 280);
    if (!text) return refuse(400, 'Write something to announce.', cors);
    let link = String(input.link || '').trim();
    if (link && !/^https:\/\/[^\s<>"']{3,300}$/.test(link)) return refuse(400, 'The link must be a full https:// address.', cors);
    const hours = Math.max(0, Math.min(24 * 30, Number(input.hours) || 0));
    const ann = { id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6), text, level: input.level === 'alert' ? 'alert' : 'info', link, at: Date.now(), until: hours ? Date.now() + hours * 3600000 : 0 };
    list.unshift(ann);
    await env.PUSH.put('ann', JSON.stringify(list.slice(0, 5)));     // at most five at a time
    memory.delete('ann:list');
    let pushed = 0;
    if (input.notify) {                                               // also as a notification, to every device signed up for them
      const subs = (await env.PUSH.get('subs', 'json')) || {};
      await Promise.all(Object.keys(subs).slice(0, 45).map(id => sendPush(env, subs[id], { title: 'Gameday Board', body: text, tag: 'gb-ann-' + ann.id }, here.origin).then(st => { if (st < 300) pushed++; }, () => {})));
    }
    return json(200, { ok: true, ann, pushed }, cors);
  }
  if (path === '/admin/remove' && request.method === 'POST') {
    const left = list.filter(a => a.id !== input.id);
    await env.PUSH.put('ann', JSON.stringify(left));
    memory.delete('ann:list');
    return json(200, { ok: true, removed: list.length - left.length }, cors);
  }
  if (path === '/admin/list' && request.method === 'GET') return json(200, { anns: list }, cors);
  return refuse(404, 'Unknown admin address.', cors);
}

export default {
  async scheduled(event, env, ctx) {
    ctx.waitUntil(watchGames(env));
  },
  async fetch(request, env) {
    const origin = request.headers.get('Origin') || '';
    const cors = corsHeaders(origin);

    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });
    if (ALLOWED_ORIGINS.length && origin && !ALLOWED_ORIGINS.includes(origin)) {
      return refuse(403, 'The website ' + origin + ' is not allowed to use this proxy.', cors);
    }
    const here = new URL(request.url);
    if (here.pathname.startsWith('/push/')) return pushRoute(request, env, here, cors);
    if (here.pathname === '/ann' || here.pathname.startsWith('/admin/')) return adminRoute(request, env, here, cors);
    if (request.method !== 'GET') return refuse(405, 'Only GET requests are allowed.', cors);

    const wanted = here.searchParams.get('url');
    if (!wanted) {
      return json(200, {
        ok: true,
        service: 'Gameday Board proxy',
        usage: here.origin + '/?url=<a scoreboard or standings address>',
        test: here.origin + '/?url=' + encodeURIComponent('https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard'),
      }, cors);
    }

    let target;
    try { target = new URL(wanted); } catch (e) { return refuse(400, 'The url value is not a valid address.', cors); }
    const rule = target.protocol === 'https:' && !target.port && !target.username && !target.password &&
      ALLOWED.find(r => r.host === target.hostname && r.path.test(target.pathname));
    if (!rule) return refuse(403, 'That address is not on this proxy\'s allow-list.', cors);

    // Rebuild the address from approved parts only.
    const clean = new URL('https://' + rule.host + target.pathname);
    for (const name of ALLOWED_PARAMS) {
      const value = target.searchParams.get(name);
      if (value !== null && SAFE_VALUE.test(value)) clean.searchParams.set(name, value);
    }
    const address = clean.toString();

    const saved = memory.get(address);
    if (saved && Date.now() - saved.at < rule.ttl * 1000) {
      return new Response(saved.body, { status: 200, headers: Object.assign({
        'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store',
        'X-Proxy-Cache': 'HIT', 'X-Upstream-Status': '200' }, cors) });
    }

    let upstream, body;
    try {
      upstream = await fetch(address, {
        headers: { 'Accept': 'application/json', 'User-Agent': 'Mozilla/5.0 (compatible; GamedayBoardProxy/1.0)' },
        redirect: 'manual',
      });
      body = await upstream.text();
    } catch (e) {
      return refuse(502, 'The proxy could not reach ' + rule.host + ': ' + (e && e.message ? e.message : 'unknown error'), cors);
    }
    if (upstream.status >= 300 && upstream.status < 400) {
      return refuse(502, rule.host + ' tried to redirect the request (HTTP ' + upstream.status + '), which this proxy does not follow.', cors);
    }

    if (upstream.status === 200 && body.length < 4000000) {
      memory.set(address, { at: Date.now(), body });
      if (memory.size > 40) memory.delete(memory.keys().next().value);
    }

    // The upstream status is passed through unchanged, so the website can report the real error.
    return new Response(body, { status: upstream.status, headers: Object.assign({
      'Content-Type': upstream.headers.get('Content-Type') || 'application/json; charset=utf-8',
      'Cache-Control': 'no-store', 'X-Proxy-Cache': 'MISS', 'X-Upstream-Status': String(upstream.status) }, cors) });
  },
};
